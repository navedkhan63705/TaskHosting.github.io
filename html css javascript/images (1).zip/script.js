var typed =new Typed(".typing",{
    strings:["","Web Designer","web Developer","Grapgic Designer","Trader"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})